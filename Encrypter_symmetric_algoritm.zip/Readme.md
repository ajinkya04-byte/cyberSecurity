🔐 Simple File Encryption & Decryption (Bash Scripts)
This repository contains two lightweight Bash scripts to encrypt and decrypt files using OpenSSL. Designed for personal use, quick protection, or educational purposes.

📁 Files
encrypt.sh – Encrypts a file using a password.
decrypt.sh – Decrypts an encrypted .enc file using the same password.
⚙️ Prerequisites
Bash (default in most Linux/macOS systems)

OpenSSL installed
Check with:

openssl version
