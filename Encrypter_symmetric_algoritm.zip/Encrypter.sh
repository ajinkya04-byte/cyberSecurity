#!/bin/bash

if [ $# -ne 1 ]; then
	echo "Usage: ./encrypt.sh <file to encrypt>"
	exit 1
fi

input_file=$1
output_file="${input_file}.enc"

openssl enc -aes-256-cbc -salt -in "$input_file" -out "output_file"

echo "file '$user_input' has been encrypted to '$output_file'"
