RSA Key Pair Generator and File Encryptor/Decryptor
This Bash script provides a simple command-line interface to generate RSA key pairs, encrypt files using the public key, and decrypt files using the private key. It leverages openssl for all cryptographic operations.

Features
RSA Key Pair Generation: Generates a 2048-bit RSA private key (private_key.pem) and optionally extracts the corresponding public key (public_key.pem).

File Encryption: Encrypts a specified file using the generated public key. The encrypted output is saved as encrypted_file1.

File Decryption: Decrypts the encrypted_file1 using the private key, saving the decrypted content to a new file (e.g., encrypted_file1_decrypted.txt).

Prerequisites
Before running this script, ensure you have openssl installed on your system. Most Linux distributions and macOS come with openssl pre-installed.

To check if openssl is installed, open your terminal and type:

Bash

openssl version
If it's not installed, you can typically install it using your system's package manager:

Debian/Ubuntu: sudo apt-get install openssl

Fedora/RHEL/CentOS: sudo dnf install openssl or sudo yum install openssl

macOS (with Homebrew): brew install openssl

How to Use
Save the script: Save the provided code into a file, for example, rsa_crypto.sh.

Make the script executable:

Bash

chmod +x rsa_crypto.sh
Run the script:

Bash

./rsa_crypto.sh
The script will then guide you through the following steps:

Key Pair Generation: It will first generate private_key.pem. You'll then be prompted if you want to extract public_key.pem.

File Encryption: If you choose to encrypt, you'll be asked to provide the path to the file you wish to encrypt. The encrypted output will be saved as encrypted_file1.

File Decryption: If you choose to decrypt, the script will attempt to decrypt encrypted_file1 and save the output to a new file (e.g., encrypted_file1_decrypted.txt).


