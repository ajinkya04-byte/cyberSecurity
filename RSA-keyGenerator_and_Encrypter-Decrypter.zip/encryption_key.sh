#!/bin/bash

#Generating the key pair for the public and private key

echo "Generating the key pair of the public and private key"

openssl genpkey -algorithm RSA -out private_key.pem -pkeyopt rsa_keygen_bits:2048

echo "Do you want to extract the public? (y/n)"

read choice

if [[ "$choice" == y || "$choice"Y ]];then
	openssl rsa -pubout -in private_key.pem -out public_key.pem
		echo "Extracted successfully! Saved as public_key.pem"

else
	echo "OK no problem"

fi

#Encrypting the file

echo "Do you want to encrypt the file?(y/n)"
read ans

if [[ "$ans" == y || "$ans" == Y ]];then 

        echo "Enter the file path:"
        read path

        openssl pkeyutl -encrypt -inkey public_key.pem -pubin -in "$path" -out encrypted_file1

        echo "Successfully encrypted the file"

else
        echo "Encryption will prevent from leaking data privacy!!"

fi

#Decrypting the file

echo "Do you want to decrypt the file?(y/n)"
read end

if [[ "$end" == y || "$end" == Y ]];then

	output_file="${encrypted_file1%.enc}_decrypted.txt"

	openssl pkeyutl -decrypt -inkey private_key.pem -in encrypted_file1 -out "$output_file"

	echo "File decrypted and saved!!"


else
	echo "You can't read the text without decrypting!"

fi
