SSL/TLS Certificate Utility
This Bash script provides an interactive way to generate RSA keys, create a Certificate Signing Request (CSR), and self-sign that request to produce an SSL/TLS certificate.

Features
RSA Key Generation: Creates private_key.pem (2048-bit).

CSR Creation: Generates request.csr from the private key.

Self-Signed Certificate: Produces certificate.pem with user-defined validity.

Certificate Viewer: Displays certificate details.

Prerequisites
openssl (usually pre-installed on Linux/macOS)

How to Use
Save: Save the script as cert_utility.sh.

Execute:

Bash

chmod +x cert_utility.sh
./cert_utility.sh
Follow the on-screen prompts.

Generated Files
private_key.pem: Your RSA private key. Keep this secret!

request.csr: The Certificate Signing Request.

certificate.pem: Your self-signed SSL/TLS certificate.

Important Notes
Testing Only: Self-signed certificates are for local development and testing only, not production environments. Browsers will show warnings.

Key Security: Protect private_key.pem to prevent unauthorized access.

Overwrites: Running the script will overwrite existing key, CSR, and certificate files in the directory.
