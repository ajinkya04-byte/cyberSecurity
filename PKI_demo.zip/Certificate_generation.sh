#!/bin/bash

#Creating a key

echo "Do you want to continue with the key generation process?(y/n)"
read res

if [[ "$res" == y || "$res" == Y ]];then
	echo "Generating Key....."
	openssl genpkey -algorithm RSA -out private_key.pem -pkeyopt rsa_keygen_bits:2048
	echo "Key generated successfully! :)"

else
	echo "Okay! :("

fi

#Certificate signing Request

echo "Do you want to self sign the certificate?(y/n)"
read res2

if [[ "$res2" == y || "$res2" == Y ]];then
	echo "Sending signing request..."
	openssl req -new -key private_key.pem -out request.csr
	echo "Request sent and saved as request.csr :)"

else
	echo "Without request you can't sign the Certs :("
fi

#Self signing the certificate

echo "Do you want to self sign the certificate?(y/n)"
read res3

if [[ "$res3" == y || "$res3" == Y ]];then
	echo "For how many days you want the certificate to be valid?"
	read validity
	openssl x509 -req -days "$validity" -in request.csr -signkey private_key.pem -out certificate.pem
	echo "Signed sucessfully! and certificate saved as certificate.pem :)"

else
	echo "The owner will if you won't !!"

fi

#Viewing the certificate

echo "You want to view the certificate?(y/n)"
read res4

if [[ "$res4" == y || "$res4" == Y ]];then
	openssl x509 -in certificate.pem -text -nnout
	cat certificate.pem

else
	echo "Okay!"

fi


